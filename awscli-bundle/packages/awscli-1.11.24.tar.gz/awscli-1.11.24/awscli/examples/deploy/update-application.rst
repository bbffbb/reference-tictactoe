**To change information about an application**

This example changes the name of an application that is associated with the user's AWS account.

Command::

  aws deploy update-application --application-name WordPress_App --new-application-name My_WordPress_App

Output::

  None.